package com.example.tricky.firebasetest;

import android.app.Activity;
import android.app.FragmentManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.design.widget.TabLayout;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.TableLayout;

import com.example.tricky.firebasetest.dummy.DummyContent;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.reward.RewardItem;
import com.google.android.gms.ads.reward.RewardedVideoAd;
import com.google.android.gms.ads.reward.RewardedVideoAdListener;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

import fr.tkeunebr.gravatar.Gravatar;

public class MainActivity extends AppCompatActivity implements  ChatMessageFragment.OnFragmentInteractionListener,
                                                                HistoryFragment.OnListFragmentInteractionListener,
                                                                MembersFragment.OnListFragmentInteractionListener, RewardedVideoAdListener {

    // Cyan 100 : #B2EBF2
    // Cyan 600 : #00ACC1
    // Cyan 900 : #006064
    // Amder 100 : #FFECB3
    // Amber 900 : #FF6F00

    final String TAG = "FirebaseTest";

    FirebaseApp mApp;
    FirebaseAuth mAuth;
    FirebaseDatabase mDatabase;

    FirebaseAuth.AuthStateListener mAuthListener;
    String mDisplayName;

    ViewPager mViewPager = null;
    FragmentAdapter mFragmentAdapter = null;

    TabLayout mTabLayout;

    AdView mAdView;
    AdRequest mBbannerAdRequest;
    InterstitialAd mInterstitialAd;
    RewardedVideoAd mRewardAd;

    int mAdvertCounter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initFirebase();
        initViewPager();
        initAdverts();
        initDatabaseChat();
    }

    private void initFirebase() {

        mApp = FirebaseApp.getInstance();
        mAuth = FirebaseAuth.getInstance(mApp);

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {

                FirebaseUser user = mAuth.getCurrentUser();

                if (user != null) {
                    Log.e(TAG, "AUTH STATE UPDATE : Valid user logged in [" + user.getEmail() + "] [" + user.getDisplayName() + "]");

                    String displayName = user.getDisplayName();

                    if (displayName != null) {
                        Log.e(TAG, "AUTH STATE UPDATE : Valid user logged in [" + user.getDisplayName() + "]");
                        mDisplayName = displayName;
                        initGravatars();
                    }
                    else
                        mDisplayName = "Unknown DisplayName";
                } else {
                    Log.e(TAG, "AUTH STATE UPDATE : NO valid user logged in");
                    mDisplayName = "No Valid User";

                    mAuth.removeAuthStateListener(mAuthListener);
                    Intent signInIntent = new Intent(getApplicationContext(), SignIn.class);
                    startActivityForResult(signInIntent, 101);
                }
            }
        };
        mAuth.addAuthStateListener(mAuthListener);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        Log.e(TAG, "Activity returned");

        if (resultCode == RESULT_OK) {
            if (requestCode == 101) {

                mDisplayName = data.getStringExtra("displayname");
                Log.e(TAG, "Intent returned Display Name [" + mDisplayName + "]");

                mAuth.addAuthStateListener(mAuthListener);
                initGravatars();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_activity_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.menu_logout) {
            Log.e(TAG, "Logout selected");

            mAuth.signOut();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void initViewPager() {

        mViewPager = (ViewPager) findViewById(R.id.viewPager);
        mFragmentAdapter = new FragmentAdapter(getSupportFragmentManager());
        mViewPager.setAdapter(mFragmentAdapter);

        mTabLayout = (TabLayout)findViewById(R.id.tabLayout);
        mTabLayout.setupWithViewPager(mViewPager);

        int tabSelectedColor = ResourcesCompat.getColor( getResources(), R.color.colorPrimaryDark, null);
        int tabNotSelectedColor = ResourcesCompat.getColor( getResources(), R.color.colorAccent, null);
        mTabLayout.setTabTextColors( tabSelectedColor, tabNotSelectedColor );

        int tabColors = ResourcesCompat.getColor( getResources(), R.color.colorPrimary, null);
        mTabLayout.setBackground(new ColorDrawable( tabColors ) );

        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {

                Log.e(TAG,"PAGE selected (" + position + ")");

                if (position == 0)
                    showHideSoftKeyboard( getApplicationContext(), getCurrentFocus(), true ); // Show keyboard
                else
                    showHideSoftKeyboard( getApplicationContext(), getCurrentFocus(), false ); // Hide keyboard

                mAdvertCounter++;

                if (mAdvertCounter % 10 == 0) {

                    if (mRewardAd.isLoaded())
                        mRewardAd.show();
                    else
                        Log.e(TAG, "REWARD AD : NOT loaded");

                    mAdvertCounter = 0;

                } else if (mAdvertCounter % 5 == 0) {

                    if (mInterstitialAd.isLoaded())
                        mInterstitialAd.show();
                    else
                        Log.e(TAG, "INTERSTITIAL AD : NOT loaded");

                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

    }

    public void onFragmentInteraction(Uri uri) {
        ;
    }

    public void onHistoryListFragmentInteraction(ChatMessage item) {;}
    public void onMembersListFragmentInteraction(String item) {;}

    public void initAdverts() {

        MobileAds.initialize( getApplicationContext(), getString(R.string.admob_app_id));

        mAdView = (AdView) findViewById(R.id.adView);
        mBbannerAdRequest = new AdRequest.Builder().build();
        mAdView.loadAd(mBbannerAdRequest);

        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId( getString(R.string.admob_interstitial_test_id));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());

       mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                super.onAdClosed();

                mInterstitialAd.loadAd(new AdRequest.Builder().build());

            }
        });

        mRewardAd  = MobileAds.getRewardedVideoAdInstance(this);
        mRewardAd.setRewardedVideoAdListener(this);
        mRewardAd.loadAd(getString(R.string.admob_reward_test_id), new AdRequest.Builder().build());

    }

    @Override
    public void onRewardedVideoAdLoaded() {
        Log.e(TAG, "REWARD AD : onRewardedVideoAdLoaded");
    }

    @Override
    public void onRewardedVideoAdOpened() {
        Log.e(TAG, "REWARD AD : onRewardedVideoAdOpened");
    }

    @Override
    public void onRewardedVideoStarted() {
        Log.e(TAG, "REWARD AD : onRewardedVideoStarted");
    }

    @Override
    public void onRewardedVideoAdClosed() {
        Log.e(TAG, "REWARD AD : onRewardedVideoAdClosed");
        mRewardAd.loadAd(getString(R.string.admob_reward_test_id), new AdRequest.Builder().build());
    }

    @Override
    public void onRewarded(RewardItem rewardItem) {
        Log.e(TAG, "REWARD AD : onRewarded");
    }

    @Override
    public void onRewardedVideoAdLeftApplication() {
        Log.e(TAG, "REWARD AD : onRewardedVideoAdLeftApplication");
    }

    @Override
    public void onRewardedVideoAdFailedToLoad(int i) {
        Log.e(TAG, "REWARD AD : onRewardedVideoAdFailedToLoad");
    }

    public void initDatabaseChat() {

        mDatabase = FirebaseDatabase.getInstance();
        DatabaseReference ref = mDatabase.getReference("chatMessages");

        ValueEventListener listener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                HistoryFragment historyFragment = (HistoryFragment)mFragmentAdapter.getItem(1);
                historyFragment.resetArray();

                MembersFragment membersFragment = (MembersFragment) mFragmentAdapter.getItem(2);
                membersFragment.resetArray();

                for (DataSnapshot child : dataSnapshot.getChildren()) {
                    ChatMessage chat = child.getValue(ChatMessage.class);

                    Log.e(TAG, chat.toString() );
                    historyFragment.routeChatMessage(chat);
                    membersFragment.routeChatMessage(chat.chatMessageSender);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        };
        ref.addValueEventListener(listener);
    }

    public void showHideSoftKeyboard(Context context, View view, boolean showKeyboard) {

        InputMethodManager imm = (InputMethodManager) context.getSystemService(Activity.INPUT_METHOD_SERVICE);

        if (showKeyboard)
            imm.showSoftInput(view, 0);
        else
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public void initGravatars() {

        String myEmail = mAuth.getCurrentUser().getEmail();
        Log.e(TAG,"Fetching/Saving Gravatar for [" + myEmail + "]");

        if (myEmail != null) {
            String gravatarURL = Gravatar.init().with(myEmail).size(100).build();

            if (mDatabase != null) {
                DatabaseReference ref = mDatabase.getReference("userGravatars").child(mDisplayName);
                ref.setValue(gravatarURL);
            }
            else
                Log.e(TAG, "Invalid Display Name");
        }
        else
            Log.e(TAG,"Invalid Email");

    }

}
