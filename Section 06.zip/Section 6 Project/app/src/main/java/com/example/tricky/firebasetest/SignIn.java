package com.example.tricky.firebasetest;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;

public class SignIn extends AppCompatActivity {

    final String TAG = "FirebaseTestSignIn";

    FirebaseApp mApp;
    FirebaseAuth mAuth;
    FirebaseAuth.AuthStateListener mAuthStateListener;

    EditText mEmailText;
    EditText mPasswordText;
    EditText mConfirmPasswordText;
    EditText mDisplayNameText;

    Button mLoginButton;
    TextView mRegisterText;

    boolean mLoginInProgress = false;
    boolean mRegisterInProgress = false;
    String mDisplayName = "Unknown";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        initControls();
        initListeners();
        initFirebase();
    }

    private void initControls() {
        mEmailText = (EditText) findViewById(R.id.emailEdit);
        mPasswordText = (EditText) findViewById(R.id.passwordEdit);
        mConfirmPasswordText = (EditText) findViewById(R.id.confirmPasswordEdit);
        mDisplayNameText = (EditText) findViewById(R.id.displayNameEdit);

        mLoginButton = (Button) findViewById(R.id.logInButton);
        mRegisterText = (TextView) findViewById(R.id.registerText);

        mEmailText.setVisibility(View.GONE);
        mPasswordText.setVisibility(View.GONE);
        mConfirmPasswordText.setVisibility(View.GONE);
        mDisplayNameText.setVisibility(View.GONE);
    }

    private void initListeners() {

        mLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mRegisterInProgress = false;

                if (!mLoginInProgress) {

                    // Login button has been hit
                    mEmailText.setVisibility(View.VISIBLE);
                    mPasswordText.setVisibility(View.VISIBLE);
                    mConfirmPasswordText.setVisibility(View.GONE);
                    mDisplayNameText.setVisibility(View.GONE);

                    mLoginInProgress = true;
                } else {

                    ;// Login button has been hit again
                    String email = mEmailText.getText().toString();
                    String password = mPasswordText.getText().toString();

                    loginUser(email, password);
                }
            }
        });

        mRegisterText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mLoginInProgress = false;

                if (!mRegisterInProgress) {

                    // Register button has been hit
                    mEmailText.setVisibility(View.VISIBLE);
                    mPasswordText.setVisibility(View.VISIBLE);
                    mConfirmPasswordText.setVisibility(View.VISIBLE);
                    mDisplayNameText.setVisibility(View.VISIBLE);

                    mRegisterInProgress = true;
                } else {

                    ;// Register button has been hit again
                    String email = mEmailText.getText().toString();
                    String password = mPasswordText.getText().toString();
                    String confirmPassword = mConfirmPasswordText.getText().toString();
                    // Validate password/password confirm here
                    mDisplayName = mDisplayNameText.getText().toString();

                    registerUser(email, password, mDisplayName);
                }
            }
        });
    }

    private void initFirebase() {

        mApp = FirebaseApp.getInstance();
        mAuth = FirebaseAuth.getInstance(mApp);

        mAuthStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {

                FirebaseUser user = firebaseAuth.getCurrentUser();

                if (user != null) {
                    mDisplayName = user.getDisplayName().toString();
                    Log.e(TAG, "SignIn : Valid current user : email [" + user.getEmail() + "] display name [" + mDisplayName + "]");

                    if (mRegisterInProgress) {
                        setDisplayName(user);
                    } else {
                        mDisplayName = user.getDisplayName();
                    }
                    mLoginInProgress = false;
                    mRegisterInProgress = false;

                    finishActivity();
                }
                else
                    Log.e(TAG, "SignIn : No Current user");
            }
        };
        mAuth.addAuthStateListener(mAuthStateListener);
    }

    private void registerUser(String email, String password, String displayName) {

        OnCompleteListener<AuthResult> complete = new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if (task.isSuccessful())
                    Log.e(TAG, "SignIn : User registered ");
                else
                    Log.e(TAG, "SignIn : User registration response, but failed ");
            }
        };

        OnFailureListener failure = new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.e(TAG,"SignIn : Register user failure");
            }
        };

        Log.e(TAG, "SignIn : Registering : eMail [" + email + "] password [" + password + "] Display Name [" + displayName + "]");
        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(complete).addOnFailureListener(failure);
    }

    private void loginUser(String email, String password) {

        OnCompleteListener<AuthResult> complete = new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if (task.isSuccessful())
                    Log.e(TAG, "SignIn : User logged on ");
                else
                    Log.e(TAG, "SignIn : User log on response, but failed ");
            }
        };

        OnFailureListener failure = new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.e(TAG,"SignIn : Log on user failure");
            }
        };

        Log.e(TAG, "SignIn : Logging in : eMail [" + email + "] password [" + password + "]");
        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(complete).addOnFailureListener(failure);
    }

    private void setDisplayName(FirebaseUser user) {
        UserProfileChangeRequest changeRequest = new UserProfileChangeRequest.Builder().setDisplayName(mDisplayName).build();
        user.updateProfile(changeRequest);
    }

    private void finishActivity() {

        Log.e(TAG,"SignIn Returning to main activity");
        mAuth.removeAuthStateListener(mAuthStateListener);

        Intent returningIntent = new Intent();
        returningIntent.putExtra("displayname", mDisplayName);
        setResult(RESULT_OK, returningIntent);

        finish();
    }
}
