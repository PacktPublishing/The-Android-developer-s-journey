package com.example.tricky.firebasetest;

import android.util.Log;

/**
 * Created by Tricky on 09/07/2018.
 */

public class ChatMessage {

    String TAG = "FirebaseTestChat";

    String chatMessageText;
    String chatMessageSendTime;
    String chatMessageSender;

    public ChatMessage() {;}

    public String getChatMessageText() { return chatMessageText; }
    public String getChatMessageSendTime() { return chatMessageSendTime; }
    public String getChatMessageSender() { return chatMessageSender; }

    public String generateKey() {

        String result = chatMessageSendTime + " " + chatMessageSender;
        return result;
    }

    public String toString() {

        String result = "Sender [" + chatMessageSender + "] Time [" + chatMessageSendTime + "] Message [" + chatMessageText + "]";
        return result;
    }

    public void logIt() {
        Log.e( TAG,toString() );
    }
}
