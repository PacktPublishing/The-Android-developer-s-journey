package com.example.tricky.meow;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    ArrayList<ImageView> mCards = new ArrayList<ImageView>();
    Button mShuffleButton;
    TextView mMeowText;
    Integer mCorrectCard;
    Random mRandomGen;
    MediaPlayer mPlayer;

   @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       mPlayer = MediaPlayer.create(this, R.raw.cat_meow);
       mCorrectCard = 99;

       for (int idx=0; idx<3;idx++) {

           ImageView card = null;

           switch (idx) {
               case 0 : card = (ImageView)findViewById(R.id.card1); break;
               case 1 : card = (ImageView)findViewById(R.id.card2); break;
               case 2 : card = (ImageView)findViewById(R.id.card3); break;

           }

           card.setTag(idx);
           card.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   selectedCard((int)view.getTag());
               }
           });
           mCards.add(card);
       }


       mShuffleButton = (Button)findViewById(R.id.shuffleButton);
       mMeowText = (TextView)findViewById(R.id.meowText);

       mRandomGen = new Random();

       mShuffleButton.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {

               for (int idx=0; idx<3;idx++) {
                   mCards.get(idx).setImageResource(R.drawable.card);
               }

               mCorrectCard = mRandomGen.nextInt(3);

               mMeowText.setText("MEOW ! " + mCorrectCard);

           }
       });
    }

    public void selectedCard(int cardNumber) {

        if (mCorrectCard != 99) {
            ImageView card = (ImageView) mCards.get(cardNumber);

            if (cardNumber == mCorrectCard) {
                card.setImageResource(R.drawable.cat);
                mPlayer.start();
            }
            else
                card.setImageResource(R.drawable.dog);
        }

        mCorrectCard = 99;
    }
}
