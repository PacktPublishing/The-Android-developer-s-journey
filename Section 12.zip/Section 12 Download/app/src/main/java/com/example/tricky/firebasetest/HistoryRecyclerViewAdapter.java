package com.example.tricky.firebasetest;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.tricky.firebasetest.HistoryFragment.OnListFragmentInteractionListener;
import com.example.tricky.firebasetest.dummy.DummyContent.DummyItem;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * {@link RecyclerView.Adapter} that can display a {@link DummyItem} and makes a call to the
 * specified {@link OnListFragmentInteractionListener}.
 * TODO: Replace the implementation with code for your data type.
 */
public class HistoryRecyclerViewAdapter extends RecyclerView.Adapter<HistoryRecyclerViewAdapter.ViewHolder> {

    String TAG = "FirebaseTestHistory";

    private final ArrayList<ChatMessage> mValues;
    private final OnListFragmentInteractionListener mListener;

    FirebaseAuth mAuth;
    String mDisplayName;

    public HistoryRecyclerViewAdapter(ArrayList<ChatMessage> items, OnListFragmentInteractionListener listener) {
        mValues = items;
        mListener = listener;

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser user = mAuth.getCurrentUser();

        mDisplayName = "Unknown";

        if (user != null) {
            String displayName = user.getDisplayName();

            if (displayName != null)
                mDisplayName = user.getDisplayName();
            else
                mDisplayName = "Unknown";
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_history, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.mItem = mValues.get(position);

        holder.mChatSenderView.setText( holder.mItem.getChatMessageSender() );
        holder.mChatSendTimeView.setText( "(" + holder.mItem.getChatMessageSendTime() + ")" );
        holder.mChatMessageTextView.setText( holder.mItem.getChatMessageText() );

        if (!mDisplayName.equals(holder.mItem.getChatMessageSender()))
            holder.mChatIcon.setImageResource(R.drawable.receivearrow);

        holder.mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != mListener) {
                    // Notify the active callbacks interface (the activity, if the
                    // fragment is attached to one) that an item has been selected.
                    mListener.onHistoryListFragmentInteraction(holder.mItem);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public final TextView mChatSenderView;
        public final TextView mChatSendTimeView;
        public final TextView mChatMessageTextView;
        public final ImageView mChatIcon;
        public ChatMessage mItem;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            mChatSenderView = (TextView) view.findViewById(R.id.chatSender);
            mChatSendTimeView = (TextView) view.findViewById(R.id.chatSendTime);
            mChatMessageTextView = (TextView) view.findViewById(R.id.chatMessageText);
            mChatIcon = (ImageView)view.findViewById(R.id.chatIcon);
        }

        @Override
        public String toString() {
            return super.toString();
        }
    }

}
