package com.example.tricky.firebasetest;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.tricky.firebasetest.MembersFragment.OnListFragmentInteractionListener;
import com.example.tricky.firebasetest.dummy.DummyContent.DummyItem;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * {@link RecyclerView.Adapter} that can display a {@link DummyItem} and makes a call to the
 * specified {@link OnListFragmentInteractionListener}.
 * TODO: Replace the implementation with code for your data type.
 */
public class MembersRecyclerViewAdapter extends RecyclerView.Adapter<MembersRecyclerViewAdapter.ViewHolder> {

    String TAG = "FirebaseTestMembers";
    //private final List<DummyItem> mValues;
    private ArrayList<String>  mValues;
    private final OnListFragmentInteractionListener mListener;

    HashMap<String, String> mUserGravatars;
    FirebaseDatabase mDatabase;
    Context mActivityContext;

    public MembersRecyclerViewAdapter(ArrayList<String> items, OnListFragmentInteractionListener listener, Context activityContext) {
        mValues = items;
        mListener = listener;
        mActivityContext = activityContext;

        initGravatars();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_members, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        String memberName = mValues.get(position);
        holder.mItem = memberName;
        holder.mChatMember.setText(memberName);

        String gravatarUrl = "http://www.gravatar.com/avatar";

        if (mUserGravatars.containsKey(memberName))
            gravatarUrl = mUserGravatars.get(memberName);

        Log.e(TAG, "Working for Gravatar URL [" + memberName + "] URL [" + gravatarUrl + "]");

        Picasso.with(mActivityContext).load(gravatarUrl).into(holder.mChatMemberIcon);

        holder.mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != mListener) {
                    // Notify the active callbacks interface (the activity, if the
                    // fragment is attached to one) that an item has been selected.
                    mListener.onMembersListFragmentInteraction(holder.mItem);
                }

            }
        });
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public final TextView mChatMember;
        public String mItem;
        public ImageView mChatMemberIcon;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            mChatMember = (TextView) view.findViewById(R.id.chatMember);
            mChatMemberIcon = (ImageView) view.findViewById(R.id.chatMemberIcon);
        }

        @Override
        public String toString() {
            return super.toString() + " '" + mItem + "'";
        }
    }

    private void initGravatars() {

        mDatabase = FirebaseDatabase.getInstance();
        mUserGravatars = new HashMap<String, String>();

        DatabaseReference ref = mDatabase.getReference("userGravatars");
        ValueEventListener listener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                mUserGravatars.clear();

                Log.e(TAG, "ON DATA CHANGE : Children [" + dataSnapshot.getChildrenCount() + "]");
                for (DataSnapshot child : dataSnapshot.getChildren() ) {

                    Log.e(TAG, "ON DATA CHANGE - CHILD");
                    String childKey = child.getKey();
                    String childValue = (String)child.getValue();

                    mUserGravatars.put(childKey, childValue);

                    Log.e(TAG,"Gravatar Node [" + childKey + "][" + childValue + "]");
                }
                notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        };
        ref.addValueEventListener(listener);
    }

}
