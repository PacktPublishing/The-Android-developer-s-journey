package com.example.tricky.firebasetest;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.tricky.firebasetest.HistoryFragment.OnListFragmentInteractionListener;
import com.example.tricky.firebasetest.dummy.DummyContent.DummyItem;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.ArrayList;

/**
 * {@link RecyclerView.Adapter} that can display a {@link DummyItem} and makes a call to the
 * specified {@link OnListFragmentInteractionListener}.
 * TODO: Replace the implementation with code for your data type.
 */
public class HistoryRecyclerViewAdapter extends RecyclerView.Adapter<HistoryRecyclerViewAdapter.ViewHolder> {

    private final ArrayList<ChatMessage> mValues;
    private final OnListFragmentInteractionListener mListener;
    FirebaseAuth mAuth;
    String mDisplayName;
    String TAG = "FirebaseTestHR";

    public HistoryRecyclerViewAdapter(ArrayList<ChatMessage> items, OnListFragmentInteractionListener listener) {
        mValues = items;
        mListener = listener;

        mAuth = FirebaseAuth.getInstance();
        mDisplayName = "Unknown";

        FirebaseUser user = mAuth.getCurrentUser();
        if (user !=  null)
            mDisplayName = user.getDisplayName();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_history, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.mItem = mValues.get(position);

        holder.mChatSender.setText( holder.mItem.getChatMessageSender() );
        holder.mChatSendTime.setText( holder.mItem.formatCardChatMessageSendTime() );
        holder.mChatText.setText( holder.mItem.getChatMessageText() );
        holder.mChatIcon.setImageResource(R.drawable.sendarrow2);

        if (!mDisplayName.equals(holder.mItem.getChatMessageSender()))
            holder.mChatIcon.setImageResource(R.drawable.sendarrow3);

        holder.mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != mListener) {
                    // Notify the active callbacks interface (the activity, if the
                    // fragment is attached to one) that an item has been selected.
                    mListener.onHistoryListFragmentInteraction(holder.mItem);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public final TextView mChatSender;
        public final TextView mChatSendTime;
        public final TextView mChatText;
        public final ImageView mChatIcon;
        public ChatMessage mItem;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            mChatSender = (TextView) view.findViewById(R.id.chatSender);
            mChatSendTime = (TextView) view.findViewById(R.id.chatSendTime);
            mChatText = (TextView) view.findViewById(R.id.chatText);
            mChatIcon = (ImageView)view.findViewById(R.id.chatIcon);
        }

        @Override
        public String toString() {
            return super.toString() + " '" + mChatSender.getText() + "'";
        }
    }
}
