package com.example.tricky.firebasetest;

import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Created by Tricky on 09/07/2018.
 */

public class ChatMessage {

    String TAG = "FirebaseTestChat";

    String chatMessageText;
    String chatMessageSendTime;
    String chatMessageSender;

    public ChatMessage() {;}

    public String getChatMessageText() { return chatMessageText; }
    public String getChatMessageSendTime() { return chatMessageSendTime; }
    public String getChatMessageSender() { return chatMessageSender; }

    public String generateKey() {

        String result = chatMessageSendTime + " " + chatMessageSender;
        return result;
    }

    public String toString() {

        String result = "Sender [" + chatMessageSender + "] Time [" + chatMessageSendTime + "] Message [" + chatMessageText + "]";
        return result;
    }

    public String formatCardChatMessageSendTime() {

        String result = "";

        try {

            Date sendTime = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH).parse(getChatMessageSendTime());
            Date nowTime = new java.util.Date();

            Calendar sendCal = Calendar.getInstance();
            sendCal.setTime(sendTime);

            Calendar nowCal = Calendar.getInstance();
            nowCal.setTime(nowTime);

            if ( (sendCal.get(Calendar.YEAR) == (nowCal.get(Calendar.YEAR)) ) &&
                 (sendCal.get(Calendar.MONTH) == (nowCal.get(Calendar.MONTH)) ) &&
                 (sendCal.get(Calendar.DAY_OF_MONTH) == (nowCal.get(Calendar.DAY_OF_MONTH)) )
                ) {
                result = "(" + "Today @ " + sendCal.get(Calendar.HOUR) + ":" + sendCal.get(Calendar.MINUTE) + ":" + sendCal.get(Calendar.SECOND) + ")";
            } else {
                result = "(" + chatMessageSendTime + ")";
            }

        } catch (ParseException e) {
            e.printStackTrace();
        }

        return result;
    }

    public void logIt() {
        Log.e( TAG,toString() );
    }
}
