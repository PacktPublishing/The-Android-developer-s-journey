package com.example.tricky.firebasetest;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

/**
 * Created by Tricky on 27/06/2018.
 */

public class FragmentAdapter extends FragmentPagerAdapter {

    HistoryFragment mHistory;
    MembersFragment mMembers;

    public FragmentAdapter(FragmentManager manager) {

        super(manager);

        mHistory = HistoryFragment.newInstance(1);
        mMembers = MembersFragment.newInstance(1);
    }

    public int getCount() { return 3; }

    public Fragment getItem(int position) {

        Fragment page = null;

        switch (position) {
            case 0: page = ChatMessageFragment.newInstance("One", "Two"); break;
            case 1: page = mHistory; break;
            case 2: page = mMembers; break;

            default : page = ChatMessageFragment.newInstance("One", "Two"); break;
        }
        return page;
    }

    public CharSequence getPageTitle(int position) {

        CharSequence result = "";

        switch (position) {
            case 0: result = "Chat"; break;
            case 1: result = "History"; break;
            case 2: result = "Members"; break;

            default : result = "Chat"; break;
        }
        return result;
    }
}
