package com.example.tricky.firebasetest;

/**
 * Created by Tricky on 26/05/2018.
 */

public class ChatMessage {

    public ChatMessage() {

    }


    public String sender;
    public String chatMessage;
    public String sentTime;

    public String getSender() { return sender; }
    public String getChatMessage() { return chatMessage; }
    public String getSentTime() { return sentTime; }
}
