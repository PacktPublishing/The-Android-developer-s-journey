package com.example.tricky.firebasetest;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    String TAG = "FirebaseTest";

    FirebaseApp mApp;
    FirebaseDatabase mDatabase;
    FirebaseAuth mAuth;
    FirebaseAuth.AuthStateListener mAuthStateListener;

    TextView mDisplayText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.e(TAG, "Now is the summer of our discontent");

        mDisplayText = (TextView)findViewById(R.id.displayText);
        mDisplayText.setText("Unknown Auth State");

        initFirebase();

        //readDatabaseData();
        //writeDatabaseData();
        //writeSecondChatMessage();
        //writeObject();

        registerUser();
        //logoutUser();
        //loginUser();
        //logoutUser();
    }

    private void initFirebase() {

        mApp = FirebaseApp.getInstance();
        mDatabase = FirebaseDatabase.getInstance(mApp);
        mAuth = FirebaseAuth.getInstance(mApp);

        mAuthStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {

                mDisplayText.setText("Auth State Update");

                FirebaseUser user = firebaseAuth.getCurrentUser();

                if (user != null)
                    Log.e(TAG, "Valid current user : " + user.getEmail());
                else
                    Log.e(TAG, "No Current user");
            }
        };
        mAuth.addAuthStateListener(mAuthStateListener);
    }

    private void readDatabaseData() {

        DatabaseReference ref = mDatabase.getReference("chatMessages");

        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                Log.e(TAG, "Snapshot received : Children " + dataSnapshot.getChildrenCount() +
                " key : " + dataSnapshot.getKey().toString() +
                " value : " + dataSnapshot.getValue().toString());

                for (DataSnapshot child : dataSnapshot.getChildren()) {

                    Log.e(TAG, "Snapshot received : Grandchildren " + child.getChildrenCount() +
                            " key : " + child.getKey().toString() +
                            " value : " + child.getValue().toString());

                    for (DataSnapshot grandchild : child.getChildren()) {

                        Log.e(TAG, "Snapshot received : Great-Grandchildren " + grandchild.getChildrenCount() +
                                " key : " + grandchild.getKey().toString() +
                                " value : " + grandchild.getValue().toString());

                    }

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        };
        ref.addValueEventListener(eventListener);

    }

    private void writeDatabaseData() {

        DatabaseReference ref = mDatabase.getReference("chatMessages").child("Andrew 12:41:23 25-05-2018");

        ref.child("sentTime").setValue("12:41:23 25-05-2018");
        ref.child("sender").setValue("Andrew");
        ref.child("chatMessage").setValue("Today is Friday and it's sunny");
    }

    private void writeSecondChatMessage() {

        DatabaseReference ref = mDatabase.getReference("chatMessages").child("Martha 01:30:12 25-05-2018");

        ref.child("sentTime").setValue("01:30:12 25-05-2018");
        ref.child("sender").setValue("Martha");
        ref.child("chatMessage").setValue("My name is Martha");

    }

    private void writeObject() {

        ChatMessage msg = new ChatMessage();
        msg.sender = "Sue";
        msg.sentTime = "11:26:01 26-05-2018";
        msg.chatMessage = "Drive my car";

        DatabaseReference ref = mDatabase.getReference("chatMessages").child("Sue 11:26:01 26-05-2018");
        ref.setValue(msg);
    }

    private void registerUser() {

        OnCompleteListener<AuthResult> complete = new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if (task.isSuccessful())
                    Log.e(TAG, "User registered ");
                else
                    Log.e(TAG, "User registration response, but failed ");
            }
        };

        OnFailureListener failure = new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.e(TAG,"Register user failure");
            }
        };

        //String email = "chilli@southsaxonsoftware.com";
        String email = "rich.p.goodman@gmail.com";
        String password = "0rang3s";

        Log.e(TAG, "Registering : eMail " + email + " password " + password);
        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(complete).addOnFailureListener(failure);
    }

    private void logoutUser() {

        Log.e(TAG, "Logging out ...");
        mAuth.signOut();

    }

    private void loginUser() {

        OnCompleteListener<AuthResult> complete = new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if (task.isSuccessful())
                    Log.e(TAG, "User logged on ");
                else
                    Log.e(TAG, "User log on response, but failed ");
            }
        };

        OnFailureListener failure = new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.e(TAG,"Log on user failure");
            }
        };

        String email = "chilli@southsaxonsoftware.com";
        String password = "0rang3s";

        Log.e(TAG, "Logging in : eMail " + email + " password " + password);
        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(complete).addOnFailureListener(failure);


    }

}

