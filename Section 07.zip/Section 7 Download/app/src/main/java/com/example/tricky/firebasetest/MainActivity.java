package com.example.tricky.firebasetest;

import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TableLayout;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity implements  ChatMessageFragment.OnFragmentInteractionListener,
                                                                ContactTestFragment.OnListFragmentInteractionListener,
                                                                HistoryTestFragment.OnListFragmentInteractionListener{

    final String TAG = "FirebaseTest";

    FirebaseApp mApp;
    FirebaseAuth mAuth;

    FirebaseAuth.AuthStateListener mAuthListener;
    String mDisplayName;

    ViewPager mViewPager = null;
    FragmentAdapter mFragmentAdapter = null;

    private TabLayout mTabManager = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initFirebase();
        initViewPager();
    }

    private void initFirebase() {

        mApp = FirebaseApp.getInstance();
        mAuth = FirebaseAuth.getInstance(mApp);

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {

                FirebaseUser user = mAuth.getCurrentUser();

                if (user != null) {
                    Log.e(TAG,"AUTH STATE UPDATE : Valid user logged in [" + user.getEmail() + "] [" + user.getDisplayName() + "]");

                    String displayName = user.getDisplayName().toString();

                    if (displayName != null)
                        mDisplayName = displayName;
                    else
                        mDisplayName = "Unknown DisplayName";
                } else {
                    Log.e(TAG,"AUTH STATE UPDATE : NO valid user logged in");
                    mDisplayName = "No Valid User";

                    mAuth.removeAuthStateListener(mAuthListener);
                    Intent signInIntent = new Intent(getApplicationContext(), SignIn.class);
                    startActivityForResult(signInIntent, 101);
                }
            }
        };
        mAuth.addAuthStateListener(mAuthListener);

    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        Log.e(TAG,"Activity returned");

        if (resultCode == RESULT_OK) {
            if (requestCode == 101) {

                mDisplayName = data.getStringExtra("displayname");
                Log.e(TAG,"Intent returned Display Name [" + mDisplayName + "]");

                mAuth.addAuthStateListener(mAuthListener);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_activity_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.menu_logout) {
            Log.e(TAG,"Logout selected");

            mAuth.signOut();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void initViewPager() {

        mViewPager = (ViewPager)findViewById(R.id.viewPager);
        mViewPager.setId(R.id.pager);

        mFragmentAdapter = new FragmentAdapter(getSupportFragmentManager());
        mViewPager.setAdapter(mFragmentAdapter);
        mTabManager = (TabLayout)findViewById(R.id.tabLayout);
        mTabManager.setupWithViewPager(mViewPager);
    }

    public void onChatMessageFragmentInteraction(Uri uri) { Log.e(TAG, "Chat message fragment"); }
    public void onContactTestListFragmentInteraction() { Log.e(TAG, "Chat message fragment"); }
    public void onHistoryTestListFragmentInteraction() { Log.e(TAG, "Chat message fragment"); }
}
