package com.example.tricky.firebasetest;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.util.Log;

/**
 * Created by Tricky on 23/06/2018.
 */

public class FragmentAdapter extends FragmentPagerAdapter {

    final String TAG = "FirebaseTestFragment";

    public FragmentAdapter(FragmentManager manager) {
        super(manager);
    }

    @Override
    public int getCount() { return 3; }

    @Override
    public Fragment getItem(int position) {

        Log.e(TAG, "Fragment Adapter get item [" + position + "]");
        switch (position) {

            case 0: return ChatMessageFragment.newInstance("Here", "Now");
            case 1: return HistoryTestFragment.newInstance(1);
            case 2: return ContactTestFragment.newInstance(2);
        }
        return null;
    }

    public CharSequence getPageTitle(int position) {

        CharSequence result = "";

        switch (position) {
            case 0: result = "Chat"; break;
            case 1: result = "History"; break;
            case 2: result = "Members"; break;
        }

        return result;
    }

}
